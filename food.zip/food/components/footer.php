<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.jpg" alt="">
         <h3>our email</h3>
         <a href="mailto:shaikhanas@gmail.com">yummy@gmail.com</a>
        
      </div>

      <div class="box">
         <img src="images/clock-icon.jpg" alt="">
         <h3>opening hours</h3>
         <p>08:00am to 10:00pm</p>
      </div>

      <div class="box">
         <img src="images/map-icon.jpg" alt="">
         <h3>our address</h3>
         <a href="#">dhaka, bangladesh</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.jpg" alt="">
         <h3>our number</h3>
         <a href="tel:1234567890">+8801790999999</a>
         <a href="tel:1112223333">+8801790000000</a>
      </div>

   </section>

  

</footer>

<div class="loader">
   <img src="images/loader.jpg" alt="">
</div>